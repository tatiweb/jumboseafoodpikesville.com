
<div id="footer">

<div class="fcred">
Copyright &copy; <?php echo date('Y');?> <a href="<?php bloginfo('siteurl'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a> - <?php bloginfo('description'); ?>.<br />
<a href="http://www.designcontest.com/website-design/" title="Website Design">Website Design</a> by <a href="http://www.fabthemes.com/" title="WordPress Themes - FabThemes.com">Fab Themes</a>.
</div>	
<div class='clear'></div>	

<?php wp_footer(); ?>

</div>

</body>
</html>      