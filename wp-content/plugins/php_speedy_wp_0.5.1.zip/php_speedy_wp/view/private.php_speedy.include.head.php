<link rel="stylesheet" href="<?php echo $speedy_lib_path ?>/libs/css/forms.css" type="text/css" />
<style type="text/css">
<!--
div#speedy_options {
padding-top:10px;
padding-left:20px;
width:90%;
margin:0 auto;
}


#speedy_options h2 {
margin-left:0px;
}

div#speedy_options label.float {
width:15%;
display:block;
float:left;
height:26px;
line-height:26px;

}

div#speedy_options input.textfield {
float:left;
width:80%;
border-right:2px solid #ccc;
border-bottom:2px solid #ccc;
}

div#speedy_options input.submit {
width:150px;
text-align:center;
}

div.spacer_small {
clear:both;
margin:0 0 0 0;
padding:0 0 0 0;
font-size:1px;
line-height:1px;
}

fieldset {
border:1px solid #ccc;
width:90%;
margin-bottom:20px;
}


fieldset legend {
font-size:1em;
}

fieldset.spd_options div.info {
background-color:#e4e4e4;
border:1px solid #CCCCCC;
margin-bottom:10px;
width:300px;
}

fieldset.spd_options label {
font-weight:normal;
background-color:#FFFFCC;
padding:3px;
display:block;
width:200px;
}

.error {
margin:0;
}

.left_label {
float:left;
width:20%;
font-weight:bold;
}

.right_label {
float:left;
width:70%;
}

ul.speedy {
list-style:outside;
margin-left:15px;
}

-->
</style>