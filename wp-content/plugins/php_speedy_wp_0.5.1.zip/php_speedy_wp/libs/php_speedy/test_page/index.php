<?php
$location = 'compress_me.php';
header("location:$location");
?>