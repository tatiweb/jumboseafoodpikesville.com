<?php	
header("Content-type: text/javascript; charset: UTF-8");
echo "
document.write('Test from .php file');
";

?>
