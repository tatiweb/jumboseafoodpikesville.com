<h1>Hmmm...we have a problem</h1>

<p><?php echo $error ?></p>

