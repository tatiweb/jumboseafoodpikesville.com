jQuery(document).ready(function($) {

    $(".business_hours_collapsible_handler").click(function() {
        $(".business_hours_collapsible").slideToggle();
        return false;
    });

});



