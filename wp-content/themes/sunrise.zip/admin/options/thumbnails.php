<?php
    $options[] = array( "name" => "Thumbnails",
    					"sicon" => "font.png",
						"type" => "heading");

	$options[] = array( "name" => "Regenerate Thumbnails",
					"desc" => "Click on <a href='".admin_url('admin.php?page=ajax-thumbnail-rebuild')."'>this link</a> to regenerate your existing thumbnails to fit the theme.",
					"type" => "info");



?>